import express from "express";
import sharp from "sharp";
import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { fileURLToPath } from "node:url";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(HERE, "..");
const DATA = path.join(ROOT, "sites.json");
const IMG = path.join(ROOT, "img");
const BACKUPS = path.join(HERE, "backups");
const CONFIG = path.join(HERE, "config.json");
const TXN = path.join(HERE, ".txn.json");
const OWNER = "manishamzon1111-cyber";
const REPO = "Lucknow-Atlas";
const PORT = Number(process.env.ATLAS_TOOL_PORT || 4173);
const USER_AGENT = "LucknowAtlasAdmin/1.0 (local research tool)";
const MAX_IMAGE_BYTES = 20 * 1024 * 1024;
const MIN_IMAGE_WIDTH = 1200;
const MIN_IMAGE_HEIGHT = 700;
const execFileAsync = promisify(execFile);
const researchCache = new Map();
const CACHE_TTL = 10 * 60 * 1000;

const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(HERE, "public")));
app.use("/img", express.static(IMG));

const clean = (value) => String(value ?? "").trim();
const escRx = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const slugify = (value) =>
  clean(value)
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/&/g, " and ")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 60);
const shortSlug = (value) =>
  slugify(value)
    .split("-")
    .map((part) => part.slice(0, 4))
    .join("")
    .slice(0, 14) || "place";
const nowStamp = () => new Date().toISOString().replace(/[:.]/g, "-");
const normalizeEntity = (value) =>
  clean(value)
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\b(avadh|oudh)\b/g, "awadh")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
const entityTokens = (value) =>
  normalizeEntity(value)
    .split(/\s+/)
    .filter(
      (token) =>
        token &&
        !["lucknow", "uttar", "pradesh", "india", "of", "the", "and"].includes(
          token,
        ),
    );
const acronym = (value) =>
  entityTokens(value)
    .map((token) => token[0])
    .join("");
function entityMatches(query, candidate) {
  const wanted = entityTokens(query);
  const available = new Set(entityTokens(candidate));
  const candidateAcronym = acronym(candidate);
  if (!wanted.length) return false;
  return wanted.every(
    (token) =>
      available.has(token) ||
      (token.length >= 2 &&
        token.length <= 5 &&
        candidateAcronym.startsWith(token)),
  );
}
const distanceMetres = (a, b) => {
  const rad = (value) => (value * Math.PI) / 180;
  const dLat = rad(Number(b.lat) - Number(a.lat));
  const dLng = rad(Number(b.lng) - Number(a.lng));
  const lat1 = rad(Number(a.lat));
  const lat2 = rad(Number(b.lat));
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 6371000 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h));
};

function coordinateConsensus(candidates, radius = 250) {
  const valid = candidates.filter(
    (item) =>
      Number.isFinite(Number(item.lat)) && Number.isFinite(Number(item.lng)),
  );
  let best = [];
  for (const anchor of valid) {
    const group = valid.filter(
      (item) => distanceMetres(anchor, item) <= radius,
    );
    const providers = new Set(group.map((item) => item.provider));
    if (providers.size > new Set(best.map((item) => item.provider)).size)
      best = group;
  }
  const providers = [...new Set(best.map((item) => item.provider))];
  const preferred =
    best.find((item) => item.provider.startsWith("Google Maps")) ||
    best.find((item) => item.provider === "OpenStreetMap") ||
    best[0] ||
    valid[0];
  return {
    verified: providers.length >= 2,
    providers,
    selected: preferred || null,
    candidates: valid.map((item) => ({
      ...item,
      agrees: preferred ? distanceMetres(preferred, item) <= radius : false,
      distance: preferred ? Math.round(distanceMetres(preferred, item)) : null,
    })),
  };
}

async function fetchOk(url, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), options.timeout || 15000);
  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
      headers: {
        "User-Agent": USER_AGENT,
        Accept: "*/*",
        ...(options.headers || {}),
      },
      redirect: "follow",
    });
    if (!response.ok)
      throw new Error(`${response.status} from ${new URL(url).hostname}`);
    return response;
  } finally {
    clearTimeout(timer);
  }
}

async function getJson(url, options) {
  return (await fetchOk(url, options)).json();
}

async function readConfig() {
  const stored = await fs.readFile(CONFIG, "utf8").then(JSON.parse, () => ({}));
  return {
    serperKey: clean(process.env.SERPER_KEY || stored.serperKey),
  };
}

async function writeConfig(input) {
  const current = await readConfig();
  const next = {
    serperKey: clean(input.serperKey) || current.serperKey,
  };
  if (input.clearSerper) next.serperKey = "";
  const temp = `${CONFIG}.${crypto.randomUUID()}.tmp`;
  await fs.writeFile(temp, `${JSON.stringify(next, null, 2)}\n`, {
    mode: 0o600,
    flag: "wx",
  });
  await fs.rename(temp, CONFIG);
  return next;
}

async function writeTxn(data) {
  const temp = `${TXN}.${crypto.randomUUID()}.tmp`;
  await fs.writeFile(temp, `${JSON.stringify(data, null, 2)}\n`, {
    flag: "wx",
  });
  await fs.rename(temp, TXN);
}

async function recoverTransaction() {
  const txn = await fs.readFile(TXN, "utf8").then(JSON.parse, () => null);
  if (!txn) return;
  const sites = await fs.readFile(DATA, "utf8").then(JSON.parse, () => []);
  const committed = sites.some((site) => site.id === txn.id);
  if (!committed) {
    if (txn.finalDir)
      await fs.rm(txn.finalDir, { recursive: true, force: true });
    if (txn.sourceFile) await fs.rm(txn.sourceFile, { force: true });
  }
  for (const target of [txn.stage, txn.tempData])
    if (target) await fs.rm(target, { recursive: true, force: true });
  await fs.rm(TXN, { force: true });
  console.log(
    `Recovered interrupted add for ${txn.id}: ${committed ? "commit retained" : "staged files rolled back"}`,
  );
}

function parseIssue(issue) {
  const field = (label) =>
    issue.body
      ?.match(new RegExp(`\\*\\*${escRx(label)}:\\*\\*\\s*(.+)`, "i"))?.[1]
      ?.trim() || "";
  const reason =
    issue.body
      ?.match(/## Why it should be included\s+([\s\S]*?)(?:\s+##|$)/i)?.[1]
      ?.trim() || "";
  return {
    number: issue.number,
    title: issue.title,
    name: field("Name") || issue.title.replace(/^Place suggestion:\s*/i, ""),
    category: field("Category"),
    location: field("Location / Maps link"),
    reason,
    url: issue.html_url,
  };
}

async function githubIssues() {
  const url = `https://api.github.com/repos/${OWNER}/${REPO}/issues?state=open&labels=suggestion&per_page=100`;
  const issues = await getJson(url, {
    headers: { Accept: "application/vnd.github+json" },
  });
  return issues.filter((item) => !item.pull_request).map(parseIssue);
}

async function wikiResearch(query) {
  const searchUrl = new URL("https://en.wikipedia.org/w/api.php");
  searchUrl.search = new URLSearchParams({
    action: "opensearch",
    search: query,
    namespace: "0",
    limit: "8",
    format: "json",
    origin: "*",
  });
  const search = await getJson(searchUrl);
  const titles = search?.[1] || [];
  if (!titles.length) return [];
  const detailUrl = new URL("https://en.wikipedia.org/w/api.php");
  detailUrl.search = new URLSearchParams({
    action: "query",
    titles: titles.join("|"),
    prop: "extracts|pageimages|coordinates|info",
    exintro: "1",
    explaintext: "1",
    piprop: "original|thumbnail",
    pithumbsize: "1200",
    inprop: "url",
    redirects: "1",
    format: "json",
    origin: "*",
  });
  const data = await getJson(detailUrl);
  const order = new Map(
    titles.map((title, index) => [title.toLowerCase(), index]),
  );
  return Object.values(data.query?.pages || {})
    .filter((page) => entityMatches(query, page.title))
    .sort(
      (a, b) =>
        (order.get(a.title.toLowerCase()) ?? 99) -
        (order.get(b.title.toLowerCase()) ?? 99),
    );
}

async function geoResearch(query) {
  const url = new URL("https://nominatim.openstreetmap.org/search");
  url.search = new URLSearchParams({
    q: `${query}, Lucknow, Uttar Pradesh, India`,
    format: "jsonv2",
    addressdetails: "1",
    extratags: "1",
    namedetails: "1",
    limit: "5",
    countrycodes: "in",
  });
  return getJson(url, { headers: { Accept: "application/json" } });
}

function decodeHtml(value = "") {
  return value
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, "&")
    .replace(/&#x27;|&#39;/g, "'")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">");
}

async function serperRequest(endpoint, query, key) {
  const data = await getJson(`https://google.serper.dev/${endpoint}`, {
    method: "POST",
    headers: {
      "X-API-KEY": key,
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({
      q: `${query} Lucknow`,
      gl: "in",
      hl: "en",
      num: 60,
    }),
  });
  if (data.message) throw new Error(data.message);
  return data;
}

async function serperSearch(query, key, images = false) {
  const data = await serperRequest(images ? "images" : "search", query, key);
  if (images)
    return (data.images || []).slice(0, 30).map((item) => ({
      url: item.imageUrl,
      pageUrl: item.link,
      source: item.source || "Google Images via Serper",
      title: item.title || query,
      width: item.imageWidth,
      height: item.imageHeight,
      provider: "Serper",
    }));
  return (data.organic || [])
    .filter((item) =>
      entityMatches(query, `${item.title || ""} ${item.snippet || ""}`),
    )
    .slice(0, 20)
    .map((item) => ({
      url: item.link,
      title: item.title,
      snippet: item.snippet,
      provider: "Serper",
    }));
}

async function serperMaps(query, key) {
  const data = await serperRequest("maps", query, key);
  return (data.places || [])
    .filter((item) => entityMatches(query, item.title || ""))
    .slice(0, 8)
    .map((item) => ({
      name: item.title,
      address: item.address,
      lat: Number(item.latitude),
      lng: Number(item.longitude),
      type: item.type,
      source: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(item.title || query)}`,
      provider: "Google Maps via Serper",
    }))
    .filter((item) => Number.isFinite(item.lat) && Number.isFinite(item.lng));
}

async function officialSearch(query, config, images = false) {
  if (!config.serperKey)
    return {
      results: [],
      warnings: [
        "No web-search API key configured. Add a free Serper key in Settings.",
      ],
    };
  try {
    const results = await serperSearch(query, config.serperKey, images);
    return {
      results,
      warnings: results.length
        ? []
        : [`Serper returned no ${images ? "image" : "web"} results.`],
    };
  } catch (error) {
    return { results: [], warnings: [`Serper failed: ${error.message}`] };
  }
}

async function pageImage(result) {
  try {
    const html = await (
      await fetchOk(result.url, {
        timeout: 9000,
        headers: { Accept: "text/html" },
      })
    ).text();
    const raw =
      html.match(
        /<meta[^>]+(?:property|name)=["'](?:og:image|twitter:image(?::src)?)["'][^>]+content=["']([^"']+)/i,
      )?.[1] ||
      html.match(
        /<meta[^>]+content=["']([^"']+)["'][^>]+(?:property|name)=["'](?:og:image|twitter:image(?::src)?)["']/i,
      )?.[1];
    if (!raw) return null;
    return {
      url: new URL(decodeHtml(raw), result.url).href,
      pageUrl: result.url,
      source: new URL(result.url).hostname.replace(/^www\./, ""),
      title: result.title,
    };
  } catch {
    return null;
  }
}

async function commonsImages(query) {
  const url = new URL("https://commons.wikimedia.org/w/api.php");
  url.search = new URLSearchParams({
    action: "query",
    generator: "search",
    gsrsearch: `${query} Lucknow filetype:bitmap`,
    gsrnamespace: "6",
    gsrlimit: "20",
    prop: "imageinfo",
    iiprop: "url|size|mime|extmetadata",
    iiurlwidth: "1400",
    format: "json",
    origin: "*",
  });
  const data = await getJson(url);
  return Object.values(data.query?.pages || {}).map((page) => {
    const info = page.imageinfo?.[0] || {};
    return {
      url: info.thumburl || info.url,
      originalUrl: info.url,
      pageUrl: info.descriptionurl,
      source: "Wikimedia Commons",
      title: page.title.replace(/^File:/, ""),
      width: info.thumbwidth || info.width,
      height: info.thumbheight || info.height,
      license: info.extmetadata?.LicenseShortName?.value || "",
    };
  });
}

function categoryFor(name, extract, suggested) {
  if (suggested && !/^not sure|other$/i.test(suggested)) return suggested;
  const text = `${name} ${extract}`.toLowerCase();
  if (/temple|mosque|masjid|imambara|church|gurudwara|shrine|dargah/.test(text))
    return "Religious";
  if (
    /kothi|palace|fort|monument|historic|heritage|built|architecture|baroque|ruins?/.test(
      text,
    )
  )
    return "Heritage";
  if (/park|forest|garden|lake|river|zoo|sanctuary|reserve/.test(text))
    return "Parks & Outdoors";
  if (/museum|gallery|cultural|market|bazaar/.test(text)) return "Culture";
  if (/university|institute|college|school/.test(text)) return "Institution";
  return "Other";
}

function yearFrom(extract = "") {
  return (
    extract.match(
      /(?:founded|established|built|completed|opened|constructed|commissioned)[^.!?]{0,80}?\b(1[5-9]\d{2}|20\d{2})\b/i,
    )?.[1] || ""
  );
}

function uniqImages(images) {
  const seen = new Set();
  return images.filter((image) => {
    if (!image?.url) return false;
    const key = image.url.replace(/^https?:/, "").replace(/\?.*$/, "");
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

async function inspectImageCandidate(candidate) {
  try {
    const response = await fetchOk(candidate.url, {
      timeout: 6000,
      headers: { Accept: "image/*" },
    });
    const declared = Number(response.headers.get("content-length") || 0);
    if (declared > MAX_IMAGE_BYTES) return null;
    const input = Buffer.from(await response.arrayBuffer());
    if (input.length > MAX_IMAGE_BYTES) return null;
    const meta = await sharp(input, { failOn: "error" }).metadata();
    if (
      !meta.width ||
      !meta.height ||
      meta.width < MIN_IMAGE_WIDTH ||
      meta.height < MIN_IMAGE_HEIGHT
    )
      return null;
    return { ...candidate, width: meta.width, height: meta.height };
  } catch {
    return null;
  }
}

async function inspectImageCandidates(candidates, onStatus = () => {}) {
  const accepted = [];
  const queue = candidates.slice(0, 48);
  const batches = Math.ceil(queue.length / 12);

  for (let index = 0; index < queue.length; index += 12) {
    const batchNumber = Math.floor(index / 12) + 1;

    onStatus(
      `Checking image batch ${batchNumber}/${batches} · ${accepted.length} valid so far`,
    );

    const batch = await Promise.all(
      queue.slice(index, index + 12).map(inspectImageCandidate),
    );

    accepted.push(...batch.filter(Boolean));

    onStatus(
      `Checked ${Math.min(index + 12, queue.length)}/${queue.length} candidates · ${accepted.length} valid`,
    );

    if (accepted.length >= 20) break;
  }

  return accepted.slice(0, 20);
}

async function cachedResearch(input) {
  const key = `research:${clean(input?.name).toLowerCase()}:${clean(input?.category).toLowerCase()}`;
  const cached = researchCache.get(key);

  if (cached && Date.now() - cached.time < CACHE_TTL) {
    onStatus(`Using cached results · ${cached.value.images?.length || 0} valid images`);
    return cached.value;
  }

  const value = await research(input);
  researchCache.set(key, { time: Date.now(), value });

  if (researchCache.size > 30)
    researchCache.delete(researchCache.keys().next().value);

  return value;
}

async function openverseImages(query) {
  const url = new URL("https://api.openverse.org/v1/images/");
  url.search = new URLSearchParams({
    q: `${query} Lucknow`,
    page_size: "40",
    mature: "false",
  });

  const data = await getJson(url, { timeout: 9000 });

  return (data.results || []).map((item) => ({
    url: item.url,
    pageUrl: item.foreign_landing_url || item.detail_url || "",
    source: `Openverse${item.source ? ` · ${item.source}` : ""}`,
    title: item.title || query,
    width: Number(item.width) || 0,
    height: Number(item.height) || 0,
    license: item.license || "",
    provider: "Openverse",
  }));
}

async function duckDuckGoImages(query) {
  const searchUrl =
    `https://duckduckgo.com/?q=${encodeURIComponent(`${query} Lucknow`)}`;

  const html = await (
    await fetchOk(searchUrl, {
      timeout: 8000,
      headers: { Accept: "text/html" },
    })
  ).text();

  const token =
    html.match(/vqd=['"]([^'"]+)/i)?.[1] ||
    html.match(/vqd=([\d-]+)/i)?.[1];

  if (!token)
    throw new Error("DuckDuckGo did not return an image-search token");

  const url = new URL("https://duckduckgo.com/i.js");
  url.search = new URLSearchParams({
    q: `${query} Lucknow`,
    vqd: token,
    o: "json",
    f: ",,,",
    p: "1",
    l: "in-en",
  });

  const data = await getJson(url, {
    timeout: 10000,
    headers: {
      Accept: "application/json",
      Referer: searchUrl,
    },
  });

  return (data.results || []).slice(0, 50).map((item) => ({
    url: item.image,
    pageUrl: item.url,
    source: item.source || "DuckDuckGo Images",
    title: item.title || query,
    width: Number(item.width) || 0,
    height: Number(item.height) || 0,
    provider: "DuckDuckGo",
  }));
}

async function bingImages(query) {
  const url = new URL("https://www.bing.com/images/search");
  url.search = new URLSearchParams({
    q: `${query} Lucknow`,
    form: "HDRSC2",
    first: "1",
    count: "50",
    qft: "+filterui:imagesize-large",
  });

  const html = await (
    await fetchOk(url, {
      timeout: 9000,
      headers: { Accept: "text/html" },
    })
  ).text();

  const results = [];

  for (const match of html.matchAll(/\sm="([^"]+)"/g)) {
    try {
      const item = JSON.parse(decodeHtml(match[1]));

      if (!item.murl) continue;

      results.push({
        url: item.murl,
        pageUrl: item.purl || "",
        source: item.turl
          ? new URL(item.turl).hostname.replace(/^www\./, "")
          : "Bing Images",
        title: item.t || query,
        width: Number(item.mw) || 0,
        height: Number(item.mh) || 0,
        provider: "Bing",
      });
    } catch {
      // Ignore malformed Bing result blocks.
    }
  }

  return results.slice(0, 50);
}

function decodeGoogleValue(value) {
  return value
    .replace(/\\u003d/g, "=")
    .replace(/\\u0026/g, "&")
    .replace(/\\u003f/g, "?")
    .replace(/\\\//g, "/")
    .replace(/\\\\/g, "\\");
}

async function googleHtmlImages(query) {
  const url = new URL("https://www.google.com/search");
  url.search = new URLSearchParams({
    q: `${query} Lucknow`,
    tbm: "isch",
    hl: "en",
    gl: "in",
    safe: "active",
  });

  const html = await (
    await fetchOk(url, {
      timeout: 9000,
      headers: {
        Accept: "text/html",
        "Accept-Language": "en-IN,en;q=0.9",
      },
    })
  ).text();

  const results = [];
  const seen = new Set();

  for (const match of html.matchAll(
    /\["(https?:\\?\/\\?\/[^"]+\.(?:jpe?g|png|webp)(?:\?[^"]*)?)",(\d+),(\d+)\]/gi,
  )) {
    const imageUrl = decodeGoogleValue(match[1]);

    if (
      seen.has(imageUrl) ||
      /gstatic\.com|googleusercontent\.com\/.*(?:logo|favicon)/i.test(imageUrl)
    )
      continue;

    seen.add(imageUrl);

    results.push({
      url: imageUrl,
      pageUrl: url.href,
      source: "Google Images HTML fallback",
      title: query,
      width: Number(match[2]) || 0,
      height: Number(match[3]) || 0,
      provider: "Google HTML",
    });
  }

  return results.slice(0, 40);
}

function interleaveImageSources(groups) {
  const output = [];
  const longest = Math.max(0, ...groups.map((group) => group.length));

  for (let index = 0; index < longest; index++) {
    for (const group of groups) {
      if (group[index]) output.push(group[index]);
    }
  }

  return output;
}

async function researchImages({ name }, onStatus = () => {}) {
  name = clean(name);

  if (!name || name.length > 120)
    throw new Error("Enter a valid place name");

  const key = `images-all:${name.toLowerCase()}`;
  const cached = researchCache.get(key);

  if (cached && Date.now() - cached.time < CACHE_TTL)
    return cached.value;

  const config = await readConfig();

  onStatus(
    "Searching Google, webpages, Wikimedia, Openverse, DuckDuckGo and Bing…",
  );

  const settled = await Promise.allSettled([
    officialSearch(name, config, true),
    officialSearch(name, config, false),
    commonsImages(name),
    openverseImages(name),
    duckDuckGoImages(name),
    bingImages(name),
    googleHtmlImages(name),
  ]);

  const result = (index, fallback) =>
    settled[index]?.status === "fulfilled"
      ? settled[index].value
      : fallback;

  const googlePack = result(0, {
    results: [],
    warnings: ["Google image search failed."],
  });

  const webPack = result(1, {
    results: [],
    warnings: ["Google web search failed."],
  });

  const commons = result(2, []);
  const openverse = result(3, []);
  const duck = result(4, []);
  const bing = result(5, []);
  const googleHtml = result(6, []);

  const webpageImages = (
    await Promise.all(
      (webPack.results || []).slice(0, 12).map(pageImage),
    )
  ).filter(Boolean);

  const groups = [
    googlePack.results || [],
    webpageImages,
    commons,
    openverse,
    duck,
    bing,
    googleHtml,
  ].map((group) =>
    group.filter((image) =>
      entityMatches(
        name,
        `${image.title || ""} ${image.pageUrl || ""}`,
      ),
    ),
  );

  const candidates = uniqImages(
    interleaveImageSources(groups),
  ).slice(0, 120);

  onStatus(
    `Sources finished · ${candidates.length} unique candidates · validating files…`,
  );

  const images = await inspectImageCandidates(candidates, onStatus);

  onStatus(`Finished · ${images.length} valid images found`);

  const warnings = [
    ...(googlePack.warnings || []),
    ...(webPack.warnings || []),
  ];

  const providerNames = [
    "Google Images via Serper",
    "Relevant webpages",
    "Wikimedia Commons",
    "Openverse",
    "DuckDuckGo",
    "Bing",
    "Google HTML fallback",
  ];

  settled.forEach((item, index) => {
    if (item.status === "rejected")
      warnings.push(
        `${providerNames[index]} failed: ${item.reason?.message || "unknown error"}`,
      );
  });

  const value = {
    images,
    warnings: [...new Set(warnings)],
    providers: groups.map((group, index) => ({
      name: providerNames[index],
      candidates: group.length,
    })),
  };

  researchCache.set(key, {
    time: Date.now(),
    value,
  });

  if (researchCache.size > 30)
    researchCache.delete(researchCache.keys().next().value);

  return value;
}

async function research({ name, category = "", location = "" }) {
  name = clean(name);
  if (!name || name.length > 120) throw new Error("Enter a valid place name");
  const query = name;
  const config = await readConfig();
  const settled = await Promise.allSettled([
    wikiResearch(query),
    geoResearch(query),
    commonsImages(query),
    officialSearch(query, config, false),
    officialSearch(query, config, true),
    config.serperKey
      ? serperMaps(query, config.serperKey)
      : Promise.resolve([]),
  ]);
  const [wiki, geo, commons, webPack, imagePack, googleMaps] = settled.map(
    (item) => (item.status === "fulfilled" ? item.value : []),
  );
  const web = webPack?.results || [];
  const apiImages = imagePack?.results || [];
  const wikiTop = wiki[0] || {};
  const geoTop = geo[0] || {};
  const pageImages = (await Promise.all(web.slice(0, 8).map(pageImage))).filter(
    Boolean,
  );
  const unverifiedImages = uniqImages([
    ...(wikiTop.original?.source
      ? [
          {
            url: wikiTop.original.source,
            pageUrl: wikiTop.fullurl,
            source: "Wikipedia",
            title: wikiTop.title,
          },
        ]
      : []),
    ...pageImages,
    ...apiImages,
    ...commons,
  ]).slice(0, 50);
  const images = await inspectImageCandidates(unverifiedImages);
  const summarySource =
    clean(wikiTop.extract) || clean(web.find((item) => item.snippet)?.snippet);
  const summary = summarySource
    .split(/(?<=[.!?])\s+/)
    .slice(0, 3)
    .join(" ")
    .slice(0, 700);
  const categoryValue = categoryFor(name, summarySource, category);
  const mapTop = googleMaps[0] || {};
  const coordCandidates = [
    ...geo.slice(0, 5).map((item) => ({
      name: item.display_name,
      lat: Number(item.lat),
      lng: Number(item.lon),
      type: item.type,
      source:
        item.osm_type && item.osm_id
          ? `https://www.openstreetmap.org/${item.osm_type}/${item.osm_id}`
          : "",
      provider: "OpenStreetMap",
    })),
    ...(wikiTop.coordinates?.[0]
      ? [
          {
            name: wikiTop.title,
            lat: Number(wikiTop.coordinates[0].lat),
            lng: Number(wikiTop.coordinates[0].lon),
            type: "article coordinate",
            source: wikiTop.fullurl,
            provider: "Wikipedia",
          },
        ]
      : []),
    ...googleMaps,
  ];
  const consensus = coordinateConsensus(coordCandidates);
  const selectedCoord = consensus.selected || {};
  const lat = Number(selectedCoord.lat);
  const lng = Number(selectedCoord.lng);
  return {
    draft: {
      id: slugify(wikiTop.title || name),
      name: wikiTop.title || name,
      category: categoryValue,
      period: categoryValue === "Heritage" ? "Historic Lucknow" : "",
      year: yearFrom(summarySource),
      lat: Number.isFinite(lat) ? lat : "",
      lng: Number.isFinite(lng) ? lng : "",
      wiki: wikiTop.title || "",
      summary,
      mapsQuery:
        geoTop.display_name ||
        mapTop.address ||
        `${name}, Lucknow, Uttar Pradesh, India`,
      coordVerified: consensus.verified ? "high" : "low",
      coordSource: selectedCoord.source || "",
    },
    geo: coordCandidates,
    coordinateConsensus: consensus,
    wiki: wiki.slice(0, 5).map((item) => ({
      title: item.title,
      extract: clean(item.extract).slice(0, 500),
      url: item.fullurl,
    })),
    web,
    images,
    providers: { serper: Boolean(config.serperKey) },
    warnings: [
      ...new Set([
        ...(webPack?.warnings || []),
        ...(imagePack?.warnings || []),
        ...settled.flatMap((item, index) => {
          const source = [
            "Wikipedia",
            "OpenStreetMap",
            "Commons",
            "web search",
            "image search",
            "Google Maps",
          ][index];
          if (item.status === "rejected")
            return [`${source} failed: ${item.reason.message}`];
          if (index < 3 && !item.value.length)
            return [`${source} returned no results.`];
          return [];
        }),
      ]),
    ],
  };
}

function validateDraft(draft, sites) {
  const required = [
    "id",
    "name",
    "category",
    "summary",
    "mapsQuery",
    "coordSource",
  ];
  for (const key of required)
    if (!clean(draft[key])) throw new Error(`Missing required field: ${key}`);
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(draft.id))
    throw new Error("ID must be a lowercase slug");
  if (
    !Number.isFinite(Number(draft.lat)) ||
    Number(draft.lat) < 26 ||
    Number(draft.lat) > 28
  )
    throw new Error("Latitude does not look like Lucknow");
  if (
    !Number.isFinite(Number(draft.lng)) ||
    Number(draft.lng) < 79 ||
    Number(draft.lng) > 82
  )
    throw new Error("Longitude does not look like Lucknow");
  if (sites.some((site) => site.id === draft.id))
    throw new Error(`Duplicate ID: ${draft.id}`);
  if (
    sites.some((site) => site.name.toLowerCase() === draft.name.toLowerCase())
  )
    throw new Error(`Place already exists: ${draft.name}`);
}

async function downloadImage(candidate, destination) {
  const response = await fetchOk(candidate.url, {
    timeout: 25000,
    headers: { Accept: "image/*" },
  });
  const declared = Number(response.headers.get("content-length") || 0);
  if (declared > MAX_IMAGE_BYTES) throw new Error("Image is larger than 20 MB");
  const input = Buffer.from(await response.arrayBuffer());
  if (input.length > MAX_IMAGE_BYTES)
    throw new Error("Image is larger than 20 MB");
  const image = sharp(input, { failOn: "error" });
  const meta = await image.metadata();
  if (
    !meta.width ||
    !meta.height ||
    meta.width < MIN_IMAGE_WIDTH ||
    meta.height < MIN_IMAGE_HEIGHT
  )
    throw new Error(
      `Image too small (${meta.width || 0}×${meta.height || 0}); minimum is ${MIN_IMAGE_WIDTH}×${MIN_IMAGE_HEIGHT}`,
    );
  await image
    .rotate()
    .resize({
      width: 2000,
      height: 1600,
      fit: "inside",
      withoutEnlargement: true,
    })
    .jpeg({ quality: 86, mozjpeg: true })
    .toFile(destination);
  return { width: meta.width, height: meta.height, bytes: input.length };
}

async function closeIssue(number, message) {
  if (!number || !process.env.GITHUB_TOKEN)
    return { closed: false, reason: "GITHUB_TOKEN is not set" };
  const url = `https://api.github.com/repos/${OWNER}/${REPO}/issues/${number}`;
  await fetchOk(url, {
    method: "PATCH",
    headers: {
      Authorization: `Bearer ${process.env.GITHUB_TOKEN}`,
      Accept: "application/vnd.github+json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ state: "closed", state_reason: "completed" }),
  });
  await fetchOk(`${url}/comments`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.GITHUB_TOKEN}`,
      Accept: "application/vnd.github+json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ body: message }),
  });
  return { closed: true };
}

async function addPlace({
  draft,
  images = [],
  coverIndex = 0,
  markerIndex = 0,
  issueNumber = null,
  coordinateEvidence = [],
  coordinateConfirmed = false,
}) {
  const sites = JSON.parse(await fs.readFile(DATA, "utf8"));
  validateDraft(draft, sites);
  const consensus = coordinateConsensus(
    Array.isArray(coordinateEvidence) ? coordinateEvidence : [],
  );
  if (!consensus.verified)
    throw new Error(
      "Coordinates need agreement from at least two independent sources within 250 metres",
    );
  if (!coordinateConfirmed)
    throw new Error("Confirm the coordinate marker on the map before adding");
  if (
    distanceMetres({ lat: draft.lat, lng: draft.lng }, consensus.selected) > 100
  )
    throw new Error(
      "Edited coordinates no longer match the verified source consensus",
    );
  if (!Array.isArray(images) || images.length === 0 || images.length > 8)
    throw new Error("Select between 1 and 8 photos");
  const folderBase = shortSlug(draft.id);
  let folder = folderBase;
  for (
    let i = 2;
    await fs.stat(path.join(IMG, folder)).then(
      () => true,
      () => false,
    );
    i++
  )
    folder = `${folderBase}${i}`;
  const stage = path.join(HERE, `.stage-${crypto.randomUUID()}`);
  const finalDir = path.join(IMG, folder);
  let sourceFile = "";
  let tempData = "";
  let committed = false;
  await fs.mkdir(stage, { recursive: true });
  const saved = [];
  try {
    for (let i = 0; i < images.length; i++) {
      const filename = `${i + 1}.jpg`;
      const info = await downloadImage(images[i], path.join(stage, filename));
      saved.push({
        path: `img/${folder}/${filename}`,
        source: images[i].pageUrl || images[i].url,
        imageUrl: images[i].url,
        ...info,
      });
    }
    const hashes = new Set();
    for (const file of await fs.readdir(stage)) {
      const hash = crypto
        .createHash("sha256")
        .update(await fs.readFile(path.join(stage, file)))
        .digest("hex");
      if (hashes.has(hash))
        throw new Error("Two selected photos are identical");
      hashes.add(hash);
    }
    const existingHashes = new Set();
    for (const site of sites)
      for (const relative of site.images || []) {
        const absolute = path.join(ROOT, relative);
        const hash = await fs.readFile(absolute).then(
          (data) => crypto.createHash("sha256").update(data).digest("hex"),
          () => "",
        );
        if (hash) existingHashes.add(hash);
      }
    for (const hash of hashes)
      if (existingHashes.has(hash))
        throw new Error("A selected photo already exists in the Atlas");
    await fs.mkdir(BACKUPS, { recursive: true });
    const stamp = nowStamp();
    await fs.copyFile(DATA, path.join(BACKUPS, `sites-${stamp}.json`));
    const entry = {
      id: clean(draft.id),
      name: clean(draft.name),
      category: clean(draft.category),
      period: clean(draft.period),
      year: clean(draft.year),
      lat: Number(draft.lat),
      lng: Number(draft.lng),
      wiki: clean(draft.wiki),
      summary: clean(draft.summary),
      images: saved.map((item) => item.path),
      cover:
        saved[Math.max(0, Math.min(Number(coverIndex) || 0, saved.length - 1))]
          .path,
      markerImage:
        saved[Math.max(0, Math.min(Number(markerIndex) || 0, saved.length - 1))]
          .path,
      mapsQuery: clean(draft.mapsQuery),
      coordVerified: clean(draft.coordVerified) || "medium",
      coordSource: clean(draft.coordSource),
    };
    const next = [...sites, entry];
    tempData = `${DATA}.${crypto.randomUUID()}.tmp`;
    await fs.writeFile(tempData, `${JSON.stringify(next, null, 2)}\n`, {
      flag: "wx",
    });
    JSON.parse(await fs.readFile(tempData, "utf8"));
    sourceFile = path.join(BACKUPS, `sources-${draft.id}-${stamp}.json`);
    await writeTxn({
      id: draft.id,
      stage,
      finalDir,
      tempData,
      sourceFile,
      state: "prepared",
    });
    await fs.rename(stage, finalDir);
    await writeTxn({
      id: draft.id,
      stage,
      finalDir,
      tempData,
      sourceFile,
      state: "images_moved",
    });
    await fs.writeFile(
      sourceFile,
      `${JSON.stringify({ place: draft.name, addedAt: new Date().toISOString(), issueNumber, coordinates: consensus, images: saved }, null, 2)}\n`,
      { flag: "wx" },
    );
    await writeTxn({
      id: draft.id,
      stage,
      finalDir,
      tempData,
      sourceFile,
      state: "sources_written",
    });
    await fs.rename(tempData, DATA);
    committed = true;
    await fs.rm(TXN, { force: true });
    const issue = await closeIssue(
      issueNumber,
      `Added **${draft.name}** to Lucknow Atlas after manual review.`,
    ).catch((error) => ({ closed: false, reason: error.message }));
    return {
      ok: true,
      entry,
      backup: path.relative(ROOT, path.join(BACKUPS, `sites-${stamp}.json`)),
      sources: path.relative(ROOT, sourceFile),
      issue,
    };
  } catch (error) {
    await fs.rm(stage, { recursive: true, force: true });
    if (!committed) {
      await fs.rm(finalDir, { recursive: true, force: true });
      if (tempData) await fs.rm(tempData, { force: true });
      if (sourceFile) await fs.rm(sourceFile, { force: true });
      await fs.rm(TXN, { force: true });
    }
    throw error;
  }
}

async function imageInfo(relative) {
  const absolute = path.resolve(ROOT, clean(relative));
  if (!absolute.startsWith(`${IMG}${path.sep}`)) return null;
  try {
    const meta = await sharp(absolute).metadata();
    return { path: relative, width: meta.width || 0, height: meta.height || 0 };
  } catch {
    return { path: relative, width: 0, height: 0, missing: true };
  }
}

async function editableSites() {
  const sites = JSON.parse(await fs.readFile(DATA, "utf8"));
  return Promise.all(
    sites.map(async (site) => ({
      ...site,
      imageDetails: await Promise.all((site.images || []).map(imageInfo)),
    })),
  );
}

async function saveSite({
  originalId,
  draft,
  images = [],
  newImages = [],
  coverRef,
  markerRef,
}) {
  const sites = JSON.parse(await fs.readFile(DATA, "utf8"));
  const index = sites.findIndex((site) => site.id === clean(originalId));
  if (index < 0) throw new Error("Place no longer exists; reload the list");
  validateDraft(draft, sites.filter((_, itemIndex) => itemIndex !== index));
  const allowed = new Set(sites[index].images || []);
  const kept = [...new Set(images.map(clean))];
  if (!kept.length) throw new Error("Keep at least one photo");
  if (kept.some((item) => !allowed.has(item)))
    throw new Error("Unknown photo path in edit request");
  if (!Array.isArray(newImages) || kept.length + newImages.length > 8)
    throw new Error("A place can have at most 8 photos");
  const folder = path.dirname(kept[0] || sites[index].images?.[0] || "").replace(/^img\//, "");
  if (!folder || folder.includes("..") || folder.includes("/"))
    throw new Error("Could not determine this place's image folder");
  const stage = path.join(HERE, `.stage-${crypto.randomUUID()}`);
  const finalDir = path.join(IMG, folder);
  const added = [];
  await fs.mkdir(stage, { recursive: true });
  try {
    const usedNumbers = new Set(
      (await fs.readdir(finalDir).catch(() => [])).map((file) => Number.parseInt(file, 10)).filter(Number.isFinite),
    );
    let number = 1;
    for (let i = 0; i < newImages.length; i++) {
      while (usedNumbers.has(number)) number++;
      const filename = `${number++}.jpg`;
      await downloadImage(newImages[i], path.join(stage, filename));
      added.push({ filename, path: `img/${folder}/${filename}` });
    }
    const existingHashes = new Set();
    for (const site of sites)
      for (const relative of site.images || []) {
        const hash = await fs.readFile(path.join(ROOT, relative)).then(
          (data) => crypto.createHash("sha256").update(data).digest("hex"),
          () => "",
        );
        if (hash) existingHashes.add(hash);
      }
    const newHashes = new Set();
    for (const item of added) {
      const hash = crypto.createHash("sha256").update(await fs.readFile(path.join(stage, item.filename))).digest("hex");
      if (existingHashes.has(hash) || newHashes.has(hash))
        throw new Error("A selected photo is already in the Atlas");
      newHashes.add(hash);
    }
    await fs.mkdir(finalDir, { recursive: true });
    for (const item of added)
      await fs.rename(path.join(stage, item.filename), path.join(finalDir, item.filename));
  } catch (error) {
    await fs.rm(stage, { recursive: true, force: true });
    for (const item of added) await fs.rm(path.join(finalDir, item.filename), { force: true });
    throw error;
  }
  const finalImages = [...kept, ...added.map((item) => item.path)];
  const resolveRef = (ref) => {
    const value = clean(ref);
    if (value.startsWith("old:")) return value.slice(4);
    if (value.startsWith("new:")) return added[Number(value.slice(4))]?.path;
    return "";
  };
  const cover = resolveRef(coverRef);
  const markerImage = resolveRef(markerRef);
  if (!finalImages.includes(cover) || !finalImages.includes(markerImage)) {
    for (const item of added) await fs.rm(path.join(finalDir, item.filename), { force: true });
    throw new Error("Choose a gallery cover and map pin from the photos being saved");
  }
  const entry = {
    ...sites[index],
    id: clean(draft.id),
    name: clean(draft.name),
    category: clean(draft.category),
    period: clean(draft.period),
    year: clean(draft.year),
    lat: Number(draft.lat),
    lng: Number(draft.lng),
    wiki: clean(draft.wiki),
    summary: clean(draft.summary),
    images: finalImages,
    cover,
    markerImage,
    mapsQuery: clean(draft.mapsQuery),
    coordVerified: clean(draft.coordVerified),
    coordSource: clean(draft.coordSource),
  };
  const stamp = nowStamp();
  await fs.mkdir(BACKUPS, { recursive: true });
  const backup = path.join(BACKUPS, `sites-${stamp}.json`);
  await fs.copyFile(DATA, backup);
  const next = [...sites];
  next[index] = entry;
  const temp = `${DATA}.${crypto.randomUUID()}.tmp`;
  await fs.writeFile(temp, `${JSON.stringify(next, null, 2)}\n`, { flag: "wx" });
  try {
    JSON.parse(await fs.readFile(temp, "utf8"));
    await fs.rename(temp, DATA);
  } catch (error) {
    await fs.rm(temp, { force: true });
    for (const item of added) await fs.rm(path.join(finalDir, item.filename), { force: true });
    throw error;
  } finally {
    await fs.rm(stage, { recursive: true, force: true });
  }
  const removed = [...allowed].filter((item) => !kept.includes(item));
  const usedElsewhere = new Set(
    sites.flatMap((site, siteIndex) =>
      siteIndex === index ? [] : site.images || [],
    ),
  );
  const removedDir = path.join(BACKUPS, `removed-${clean(originalId)}-${stamp}`);
  if (removed.length) await fs.mkdir(removedDir, { recursive: true });
  for (const relative of removed) {
    if (usedElsewhere.has(relative)) continue;
    const absolute = path.resolve(ROOT, relative);
    if (!absolute.startsWith(`${IMG}${path.sep}`)) continue;
    const target = path.join(removedDir, path.basename(absolute));
    await fs.copyFile(absolute, target).then(
      () => fs.unlink(absolute),
      () => undefined,
    );
  }
  return { ok: true, entry, backup: path.relative(ROOT, backup) };
}

async function git(args) {
  const { stdout = "", stderr = "" } = await execFileAsync("git", args, {
    cwd: ROOT,
    maxBuffer: 2 * 1024 * 1024,
  });
  return clean(stdout || stderr);
}

async function publishStatus() {
  const [branch, remote, status] = await Promise.all([
    git(["branch", "--show-current"]),
    git(["remote", "get-url", "origin"]),
    git(["status", "--short"]),
  ]);
  return { branch, remote, status, clean: !status };
}

async function publish({ confirmed, message }) {
  if (confirmed !== true) throw new Error("Publishing requires confirmation");
  const before = await publishStatus();
  if (before.branch !== "main") throw new Error(`Publishing is allowed only from main (current: ${before.branch})`);
  if (!/(?:github\.com[:/])manishamzon1111-cyber\/Lucknow-Atlas(?:\.git)?$/i.test(before.remote))
    throw new Error("origin is not the Lucknow-Atlas GitHub repository");
  await git(["add", "--", "app.js", "sites.json", "img", "tool"]);
  const staged = await git(["diff", "--cached", "--name-only"]);
  if (!staged) throw new Error("There are no Atlas changes to publish");
  await git(["commit", "-m", clean(message) || "Update Lucknow Atlas places"]);
  await git(["push", "origin", "main"]);
  const sha = await git(["rev-parse", "HEAD"]);
  return {
    ok: true,
    sha,
    files: staged.split("\n"),
    githubUrl: `https://github.com/${OWNER}/${REPO}/commit/${sha}`,
    deployment: "GitHub push succeeded. A Vercel deployment is triggered only when this repository is connected to the Vercel project.",
  };
}

app.get("/api/issues", async (_req, res) => {
  try {
    res.json({ issues: await githubIssues() });
  } catch (error) {
    res.status(502).json({ error: error.message });
  }
});

app.get("/api/sites", async (_req, res) => {
  try { res.json({ sites: await editableSites() }); }
  catch (error) { res.status(500).json({ error: error.message }); }
});

app.post("/api/site/save", async (req, res) => {
  try { res.json(await saveSite(req.body || {})); }
  catch (error) { res.status(400).json({ error: error.message }); }
});

app.get("/api/publish/status", async (_req, res) => {
  try { res.json(await publishStatus()); }
  catch (error) { res.status(500).json({ error: error.message }); }
});

app.post("/api/publish", async (req, res) => {
  try { res.json(await publish(req.body || {})); }
  catch (error) { res.status(400).json({ error: error.message }); }
});

app.get("/api/images/stream", async (req, res) => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders();

  const send = (type, data) => {
    res.write(`event: ${type}\n`);
    res.write(`data: ${JSON.stringify(data)}\n\n`);
  };

  try {
    const result = await researchImages(
      { name: req.query.name },
      (message) => send("status", { message }),
    );

    send("result", result);
  } catch (error) {
    send("failure", {
      error: error.message || "Image search failed",
    });
  } finally {
    res.end();
  }
});

app.post("/api/images", async (req, res) => {
  try {
    res.json(await researchImages(req.body || {}));
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.post("/api/research", async (req, res) => {
  try {
    res.json(await cachedResearch(req.body || {}));
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.post("/api/add", async (req, res) => {
  try {
    res.json(await addPlace(req.body || {}));
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.get("/api/status", async (_req, res) => {
  try {
    const sites = JSON.parse(await fs.readFile(DATA, "utf8"));
    const config = await readConfig();
    res.json({
      ok: true,
      places: sites.length,
      root: ROOT,
      providers: { serper: Boolean(config.serperKey) },
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.post("/api/settings", async (req, res) => {
  try {
    const config = await writeConfig(req.body || {});
    res.json({
      ok: true,
      providers: { serper: Boolean(config.serperKey) },
    });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

if (path.resolve(process.argv[1] || "") === fileURLToPath(import.meta.url)) {
  await recoverTransaction();
  app.listen(PORT, "127.0.0.1", () =>
    console.log(`Lucknow Atlas review tool: http://localhost:${PORT}`),
  );
}

export {
  app,
  parseIssue,
  slugify,
  validateDraft,
  shortSlug,
  recoverTransaction,
  coordinateConsensus,
  distanceMetres,
  entityMatches,
};
